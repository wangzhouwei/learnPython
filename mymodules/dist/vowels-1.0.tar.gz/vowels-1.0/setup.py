from setuptools import setup
setup(
    name = 'vowels',
    version = '1.0',
    description = 'the head first python search Tools',
    author = 'wzw',
    author_email = 'wzwf2@gmail.com',
    py_modules = ['vowels'],
)